package com.torchpixelart;

/**
 * Виды падения. Для каждого факела считается задержка (в тиках) до его удаления.
 * Внутри столбца факелы всегда убираются сверху вниз, поэтому факелы никогда
 * не "выпадают сами" и не засоряют мир предметами.
 */
public enum FallMode {
    WAVE("wave", "Волна от факела"),
    DIAGONAL("diagonal", "Диагональ"),
    LEFT_RIGHT("left", "Слева направо"),
    RIGHT_LEFT("right", "Справа налево"),
    CENTER_OUT("center", "От центра"),
    EDGES_IN("edges", "От краёв к центру"),
    RANDOM("random", "Случайные столбцы"),
    WATERFALL("waterfall", "Водопад сверху"),
    INSTANT("instant", "Всё сразу");

    public final String id;
    public final String label;

    FallMode(String id, String label) {
        this.id = id;
        this.label = label;
    }

    public static FallMode byId(String id) {
        for (FallMode m : values()) {
            if (m.id.equalsIgnoreCase(id)) return m;
        }
        return null;
    }

    /**
     * Исходная задержка в тиках для факела (cx - столбец, ti - номер факела снизу).
     * sx, si - факел, который сломал игрок.
     */
    public double raw(int cx, int ti, int w, int h, int sx, int si, int seed) {
        int top = h - 2;
        int fromTop = top - ti;
        double mid = (w - 1) / 2.0;
        return switch (this) {
            case WAVE -> Math.hypot(cx - sx, ti - si) * 0.7;
            case DIAGONAL -> (cx + fromTop) * 0.8;
            case LEFT_RIGHT -> cx * 1.5 + fromTop * 0.1;
            case RIGHT_LEFT -> (w - 1 - cx) * 1.5 + fromTop * 0.1;
            case CENTER_OUT -> Math.abs(cx - mid) * 2.0 + fromTop * 0.3;
            case EDGES_IN -> (mid - Math.abs(cx - mid)) * 2.0 + fromTop * 0.3;
            case RANDOM -> columnHash(cx, seed) % 90 + fromTop * 0.2;
            case WATERFALL -> fromTop * 1.5;
            case INSTANT -> 0.0;
        };
    }

    private static int columnHash(int cx, int seed) {
        int x = cx * 0x9E3779B1 + seed * 0x85EBCA6B;
        x ^= x >>> 15;
        x *= 0x2C1B3C6D;
        x ^= x >>> 12;
        return x >>> 1;
    }
}
