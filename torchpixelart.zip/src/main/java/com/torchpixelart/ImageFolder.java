package com.torchpixelart;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/** Папка .minecraft/pixelart, куда кладутся картинки. */
public final class ImageFolder {
    private ImageFolder() {}

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().toAbsolutePath().normalize().resolve("pixelart");
    }

    public static List<String> list() {
        List<String> result = new ArrayList<>();
        try {
            Files.createDirectories(dir());
            try (Stream<Path> s = Files.list(dir())) {
                s.filter(Files::isRegularFile)
                        .map(p -> p.getFileName().toString())
                        .filter(n -> {
                            String l = n.toLowerCase(Locale.ROOT);
                            return l.endsWith(".png") || l.endsWith(".jpg") || l.endsWith(".jpeg")
                                    || l.endsWith(".gif") || l.endsWith(".bmp");
                        })
                        .sorted(String.CASE_INSENSITIVE_ORDER)
                        .forEach(result::add);
            }
        } catch (IOException ignored) {
            // папки нет или нет доступа - вернём пустой список
        }
        return result;
    }
}
