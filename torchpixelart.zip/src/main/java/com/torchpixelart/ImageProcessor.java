package com.torchpixelart;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/** Загрузка картинки, масштабирование и подбор цветов под палитру блоков. */
public final class ImageProcessor {
    private ImageProcessor() {}

    public static final int MAX_SIZE = 128;

    public static BufferedImage load(File file) throws IOException {
        BufferedImage img = ImageIO.read(file);
        if (img == null) {
            throw new IOException("формат не поддерживается (нужен PNG, JPG, GIF или BMP)");
        }
        return img;
    }

    public static int autoHeight(BufferedImage img, int width) {
        int h = (int) Math.round(width * (double) img.getHeight() / img.getWidth());
        return Math.max(2, Math.min(MAX_SIZE, h));
    }

    /** Возвращает индексы палитры, построчно сверху вниз: pix[y * w + x]. */
    public static int[] quantize(BufferedImage img, int w, int h, boolean dither) {
        int sw = img.getWidth();
        int sh = img.getHeight();
        float[] r = new float[w * h];
        float[] g = new float[w * h];
        float[] b = new float[w * h];

        for (int y = 0; y < h; y++) {
            int y0 = (int) ((long) y * sh / h);
            int y1 = Math.min(sh, Math.max(y0 + 1, (int) ((long) (y + 1) * sh / h)));
            int stepY = Math.max(1, (y1 - y0) / 8);
            for (int x = 0; x < w; x++) {
                int x0 = (int) ((long) x * sw / w);
                int x1 = Math.min(sw, Math.max(x0 + 1, (int) ((long) (x + 1) * sw / w)));
                int stepX = Math.max(1, (x1 - x0) / 8);
                long sr = 0, sg = 0, sb = 0;
                int n = 0;
                for (int yy = y0; yy < y1; yy += stepY) {
                    for (int xx = x0; xx < x1; xx += stepX) {
                        int p = img.getRGB(xx, yy);
                        int a = p >>> 24;
                        int pr = (p >> 16) & 255, pg = (p >> 8) & 255, pb = p & 255;
                        // прозрачное считаем белым фоном
                        pr = (pr * a + 255 * (255 - a)) / 255;
                        pg = (pg * a + 255 * (255 - a)) / 255;
                        pb = (pb * a + 255 * (255 - a)) / 255;
                        sr += pr;
                        sg += pg;
                        sb += pb;
                        n++;
                    }
                }
                int i = y * w + x;
                r[i] = sr / (float) n;
                g[i] = sg / (float) n;
                b[i] = sb / (float) n;
            }
        }

        int[] out = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                float cr = clamp(r[i]), cg = clamp(g[i]), cb = clamp(b[i]);
                int best = Palette.nearest(Math.round(cr), Math.round(cg), Math.round(cb));
                out[i] = best;
                if (dither) {
                    int pc = Palette.RGB[best];
                    float er = cr - ((pc >> 16) & 255);
                    float eg = cg - ((pc >> 8) & 255);
                    float eb = cb - (pc & 255);
                    spread(r, g, b, w, h, x + 1, y, er, eg, eb, 7f / 16f);
                    spread(r, g, b, w, h, x - 1, y + 1, er, eg, eb, 3f / 16f);
                    spread(r, g, b, w, h, x, y + 1, er, eg, eb, 5f / 16f);
                    spread(r, g, b, w, h, x + 1, y + 1, er, eg, eb, 1f / 16f);
                }
            }
        }
        return out;
    }

    private static void spread(float[] r, float[] g, float[] b, int w, int h, int x, int y,
                               float er, float eg, float eb, float k) {
        if (x < 0 || x >= w || y < 0 || y >= h) return;
        int i = y * w + x;
        r[i] += er * k;
        g[i] += eg * k;
        b[i] += eb * k;
    }

    private static float clamp(float v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }
}
