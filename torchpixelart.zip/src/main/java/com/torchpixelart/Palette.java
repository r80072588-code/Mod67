package com.torchpixelart;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;

/** Палитра: блоки с гравитацией (бетонный порошок, песок, гравий) и их средние цвета. */
public final class Palette {
    private Palette() {}

    public static final int[] RGB = {
            0xE2E3E4, // white
            0xE38524, // orange
            0xC053B8, // magenta
            0x4AB4D5, // light blue
            0xE9C737, // yellow
            0x7DBD2A, // lime
            0xE499B5, // pink
            0x4D5154, // gray
            0x9B9B94, // light gray
            0x24939D, // cyan
            0x8337B1, // purple
            0x4649A6, // blue
            0x7E5536, // brown
            0x62772D, // green
            0xA83632, // red
            0x191A1F, // black
            0xDBCFA3, // sand
            0xBE6621, // red sand
            0x837F7E  // gravel
    };

    public static final Block[] BLOCKS = {
            Blocks.WHITE_CONCRETE_POWDER,
            Blocks.ORANGE_CONCRETE_POWDER,
            Blocks.MAGENTA_CONCRETE_POWDER,
            Blocks.LIGHT_BLUE_CONCRETE_POWDER,
            Blocks.YELLOW_CONCRETE_POWDER,
            Blocks.LIME_CONCRETE_POWDER,
            Blocks.PINK_CONCRETE_POWDER,
            Blocks.GRAY_CONCRETE_POWDER,
            Blocks.LIGHT_GRAY_CONCRETE_POWDER,
            Blocks.CYAN_CONCRETE_POWDER,
            Blocks.PURPLE_CONCRETE_POWDER,
            Blocks.BLUE_CONCRETE_POWDER,
            Blocks.BROWN_CONCRETE_POWDER,
            Blocks.GREEN_CONCRETE_POWDER,
            Blocks.RED_CONCRETE_POWDER,
            Blocks.BLACK_CONCRETE_POWDER,
            Blocks.SAND,
            Blocks.RED_SAND,
            Blocks.GRAVEL
    };

    public static final BlockState[] STATES = new BlockState[BLOCKS.length];

    static {
        for (int i = 0; i < BLOCKS.length; i++) {
            STATES[i] = BLOCKS[i].getDefaultState();
        }
    }

    /** Ближайший по цвету элемент палитры (взвешенное RGB-расстояние). */
    public static int nearest(int r, int g, int b) {
        int best = 0;
        long bestDist = Long.MAX_VALUE;
        for (int i = 0; i < RGB.length; i++) {
            int c = RGB[i];
            int cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
            long rm = (r + cr) / 2;
            long dr = r - cr, dg = g - cg, db = b - cb;
            long d = (((512 + rm) * dr * dr) >> 8) + 4 * dg * dg + (((767 - rm) * db * db) >> 8);
            if (d < bestDist) {
                bestDist = d;
                best = i;
            }
        }
        return best;
    }
}
