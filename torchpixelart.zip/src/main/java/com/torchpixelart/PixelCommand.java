package com.torchpixelart;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Direction;

import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;

/**
 * /pixelart list
 * /pixelart build "файл.png" [ширина] [высота (0 = авто)] [режим] [дизеринг]
 * /pixelart fall
 */
public final class PixelCommand {
    private PixelCommand() {}

    private static final int WALL_DISTANCE = 5;

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
                CommandManager.literal("pixelart")
                        .requires(src -> src.hasPermissionLevel(2) || !src.getServer().isDedicated())
                        .then(CommandManager.literal("list")
                                .executes(ctx -> list(ctx.getSource())))
                        .then(CommandManager.literal("fall")
                                .executes(ctx -> fall(ctx.getSource())))
                        .then(CommandManager.literal("build")
                                .then(CommandManager.argument("file", StringArgumentType.string())
                                        .suggests(PixelCommand::suggestFiles)
                                        .executes(ctx -> run(ctx, false, false, false, false))
                                        .then(CommandManager.argument("width", IntegerArgumentType.integer(4, 128))
                                                .executes(ctx -> run(ctx, true, false, false, false))
                                                .then(CommandManager.argument("height", IntegerArgumentType.integer(0, 128))
                                                        .executes(ctx -> run(ctx, true, true, false, false))
                                                        .then(CommandManager.argument("mode", StringArgumentType.word())
                                                                .suggests(PixelCommand::suggestModes)
                                                                .executes(ctx -> run(ctx, true, true, true, false))
                                                                .then(CommandManager.argument("dither", BoolArgumentType.bool())
                                                                        .executes(ctx -> run(ctx, true, true, true, true))))))))
        );
    }

    private static int run(CommandContext<ServerCommandSource> ctx, boolean hasWidth, boolean hasHeight,
                           boolean hasMode, boolean hasDither) throws CommandSyntaxException {
        ServerCommandSource src = ctx.getSource();
        String file = StringArgumentType.getString(ctx, "file");
        int width = hasWidth ? IntegerArgumentType.getInteger(ctx, "width") : 64;
        int height = hasHeight ? IntegerArgumentType.getInteger(ctx, "height") : 0;
        FallMode mode = FallMode.WAVE;
        if (hasMode) {
            String id = StringArgumentType.getString(ctx, "mode");
            mode = FallMode.byId(id);
            if (mode == null) {
                src.sendError(Text.literal("Неизвестный режим: " + id));
                return 0;
            }
        }
        boolean dither = !hasDither || BoolArgumentType.getBool(ctx, "dither");
        return build(src, file, width, height, mode, dither);
    }

    private static int build(ServerCommandSource src, String file, int w, int hRequested,
                             FallMode mode, boolean dither) throws CommandSyntaxException {
        ServerPlayerEntity player = src.getPlayerOrThrow();
        ServerWorld world = src.getWorld();

        Path dir = ImageFolder.dir();
        Path path;
        try {
            path = dir.resolve(file).normalize();
        } catch (RuntimeException e) {
            src.sendError(Text.literal("Неверное имя файла: " + file));
            return 0;
        }
        if (!path.startsWith(dir) || !Files.isRegularFile(path)) {
            src.sendError(Text.literal("Файл не найден в папке pixelart: " + file));
            return 0;
        }

        BufferedImage img;
        try {
            img = ImageProcessor.load(path.toFile());
        } catch (Exception e) {
            src.sendError(Text.literal("Не удалось открыть картинку: " + e.getMessage()));
            return 0;
        }

        int h = hRequested <= 0 ? ImageProcessor.autoHeight(img, w) : hRequested;
        h = Math.max(2, h);

        int baseY = player.getBlockY();
        int topY = baseY + 2 * h - 2;
        if (topY >= world.getTopY()) {
            int maxH = (world.getTopY() - 1 - baseY + 2) / 2;
            src.sendError(Text.literal("Не помещается по высоте. Стена в высоту занимает " + (2 * h - 1)
                    + " блоков. Уменьши высоту (здесь максимум около " + Math.max(2, maxH)
                    + ") или встань ниже."));
            return 0;
        }
        if (baseY - 1 < world.getBottomY()) {
            src.sendError(Text.literal("Слишком низко для постройки."));
            return 0;
        }

        Direction forward = player.getHorizontalFacing();
        Direction right = forward.rotateYClockwise();
        int ox = player.getBlockX() + forward.getOffsetX() * WALL_DISTANCE - right.getOffsetX() * (w / 2);
        int oz = player.getBlockZ() + forward.getOffsetZ() * WALL_DISTANCE - right.getOffsetZ() * (w / 2);

        int[] pix = ImageProcessor.quantize(img, w, h, dither);
        Wall wall = new Wall(world, player.getUuid(), ox, baseY, oz, right, forward, w, h, pix, mode,
                ThreadLocalRandom.current().nextInt());
        WallManager.add(wall);

        final int fw = w;
        final int fh = h;
        final String modeLabel = mode.label;
        src.sendFeedback(() -> Text.literal("Строю " + fw + "x" + fh + " блоков, режим: " + modeLabel
                + ". Стена появится перед тобой, потом сломай любой факел."), false);
        return 1;
    }

    private static int fall(ServerCommandSource src) throws CommandSyntaxException {
        ServerWorld world = src.getWorld();
        Wall wall = WallManager.nearestReady(world, src.getPosition());
        if (wall == null) {
            if (WallManager.hasBuilding(world)) {
                src.sendError(Text.literal("Стена ещё строится, подожди секунду."));
            } else {
                src.sendError(Text.literal("Нет готовой стены поблизости."));
            }
            return 0;
        }
        WallManager.startFall(src.getServer(), wall, wall.w / 2, 0);
        return 1;
    }

    private static int list(ServerCommandSource src) {
        List<String> files = ImageFolder.list();
        if (files.isEmpty()) {
            src.sendFeedback(() -> Text.literal("В папке .minecraft/pixelart нет картинок (PNG/JPG/GIF/BMP)."), false);
        } else {
            src.sendFeedback(() -> Text.literal("Картинки: " + String.join(", ", files)), false);
        }
        return files.size();
    }

    private static CompletableFuture<Suggestions> suggestFiles(CommandContext<ServerCommandSource> ctx,
                                                               SuggestionsBuilder builder) {
        for (String f : ImageFolder.list()) {
            builder.suggest("\"" + f.replace("\\", "\\\\").replace("\"", "\\\"") + "\"");
        }
        return builder.buildFuture();
    }

    private static CompletableFuture<Suggestions> suggestModes(CommandContext<ServerCommandSource> ctx,
                                                               SuggestionsBuilder builder) {
        String start = builder.getRemainingLowerCase();
        for (FallMode m : FallMode.values()) {
            if (m.id.startsWith(start)) builder.suggest(m.id);
        }
        return builder.buildFuture();
    }
}
