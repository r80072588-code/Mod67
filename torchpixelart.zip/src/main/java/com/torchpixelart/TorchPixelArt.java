package com.torchpixelart;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

public class TorchPixelArt implements ModInitializer {
    public static final String MOD_ID = "torchpixelart";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess, environment) -> PixelCommand.register(dispatcher));
        WallManager.init();
    }
}
