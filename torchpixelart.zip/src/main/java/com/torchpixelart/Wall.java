package com.torchpixelart;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.Arrays;
import java.util.UUID;

/**
 * Одна стена-картинка. Геометрия: столбцы идут вправо от зрителя, по высоте блоки
 * чередуются: блок картинки, факел, блок, факел, ... Каждый блок лежит на факеле.
 * Когда факелы убрать сверху вниз, блоки падают и складываются в готовую картину.
 */
final class Wall {
    enum Phase { BUILDING, READY, FALLING, DONE }

    private static final BlockState PLATFORM = Blocks.SMOOTH_STONE.getDefaultState();
    private static final BlockState TORCH = Blocks.TORCH.getDefaultState();

    final ServerWorld world;
    final UUID owner;
    final int ox, oy, oz;   // позиция столбца 0, слой 0 (низ картины)
    final int rx, rz;       // направление столбцов (вправо от зрителя)
    final int nx, nz;       // куда смотрит зритель (нормаль стены)
    final int w, h;
    final int[] pix;        // индексы палитры, построчно сверху вниз
    final FallMode mode;
    final int seed;

    Phase phase = Phase.BUILDING;
    int buildCursor = 0;
    long[] schedule = new long[0];
    int fallCursor = 0;
    int fallStart = 0;
    int doneTick = 0;

    Wall(ServerWorld world, UUID owner, int ox, int oy, int oz, Direction right, Direction forward,
         int w, int h, int[] pix, FallMode mode, int seed) {
        this.world = world;
        this.owner = owner;
        this.ox = ox;
        this.oy = oy;
        this.oz = oz;
        this.rx = right.getOffsetX();
        this.rz = right.getOffsetZ();
        this.nx = forward.getOffsetX();
        this.nz = forward.getOffsetZ();
        this.w = w;
        this.h = h;
        this.pix = pix;
        this.mode = mode;
        this.seed = seed;
    }

    int layers() {
        return 2 * h - 1;
    }

    int totalCells() {
        return w + layers() * w;
    }

    /** Позиция клетки по номеру: сначала платформа (w клеток), потом слои снизу вверх. */
    void cellPos(int c, BlockPos.Mutable m) {
        if (c < w) {
            m.set(ox + rx * c, oy - 1, oz + rz * c);
        } else {
            int c2 = c - w;
            int k = c2 / w;
            int cx = c2 % w;
            m.set(ox + rx * cx, oy + k, oz + rz * cx);
        }
    }

    BlockState cellState(int c) {
        if (c < w) return PLATFORM;
        int c2 = c - w;
        int k = c2 / w;
        int cx = c2 % w;
        if ((k & 1) == 1) return TORCH;
        int i = k / 2;               // номер блока снизу
        int ry = h - 1 - i;          // строка в картинке (0 - верх)
        return Palette.STATES[pix[ry * w + cx]];
    }

    void torchPos(int cx, int ti, BlockPos.Mutable m) {
        m.set(ox + rx * cx, oy + 2 * ti + 1, oz + rz * cx);
    }

    /** Если pos - факел этой стены, возвращает {столбец, номер факела снизу}. */
    int[] torchIndex(BlockPos p) {
        int dx = p.getX() - ox;
        int dz = p.getZ() - oz;
        int dy = p.getY() - oy;
        int cx = dx * rx + dz * rz;
        int dn = dx * nx + dz * nz;
        if (dn != 0 || cx < 0 || cx >= w) return null;
        if (dy < 1 || dy > 2 * h - 3 || (dy & 1) == 0) return null;
        return new int[]{cx, (dy - 1) / 2};
    }

    /**
     * Расписание удаления факелов. Ключ: задержка | (сверху вниз) | столбец.
     * После сортировки в одном столбце факелы идут строго сверху вниз.
     */
    long[] buildSchedule(int sx, int si) {
        int tCount = h - 1;
        long[] keys = new long[w * tCount];
        double[] col = new double[tCount];
        int n = 0;
        for (int cx = 0; cx < w; cx++) {
            for (int ti = 0; ti < tCount; ti++) {
                col[ti] = mode.raw(cx, ti, w, h, sx, si, seed);
            }
            // верхний факел не может сниматься позже нижнего
            for (int ti = 1; ti < tCount; ti++) {
                col[ti] = Math.min(col[ti], col[ti - 1]);
            }
            for (int ti = 0; ti < tCount; ti++) {
                int d = (int) Math.round(col[ti]);
                if (cx == sx && ti > si) d = 0; // над сломанным факелом всё падает сразу
                keys[n++] = ((long) d << 40) | ((long) (tCount - 1 - ti) << 20) | cx;
            }
        }
        Arrays.sort(keys);
        return keys;
    }
}
