package com.torchpixelart;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Строит стены по тикам и запускает падение, когда игрок ломает факел. */
public final class WallManager {
    private WallManager() {}

    private static final int BUILD_PER_TICK = 1500;
    private static final int REMOVE_PER_TICK = 1200;
    private static final List<Wall> WALLS = new ArrayList<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(WallManager::tick);
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> WALLS.clear());
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(world instanceof ServerWorld serverWorld) || !state.isOf(Blocks.TORCH)) return;
            for (Wall wall : WALLS) {
                if (wall.world == serverWorld && wall.phase == Wall.Phase.READY) {
                    int[] idx = wall.torchIndex(pos);
                    if (idx != null) {
                        startFall(serverWorld.getServer(), wall, idx[0], idx[1]);
                        break;
                    }
                }
            }
        });
    }

    static void add(Wall wall) {
        WALLS.add(wall);
    }

    /** Ближайшая готовая стена в этом мире. */
    static Wall nearestReady(ServerWorld world, Vec3d from) {
        Wall best = null;
        double bestDist = Double.MAX_VALUE;
        for (Wall wall : WALLS) {
            if (wall.world != world || wall.phase != Wall.Phase.READY) continue;
            double cx = wall.ox + wall.rx * (wall.w / 2.0);
            double cz = wall.oz + wall.rz * (wall.w / 2.0);
            double dx = cx - from.x;
            double dz = cz - from.z;
            double d = dx * dx + dz * dz;
            if (d < bestDist) {
                bestDist = d;
                best = wall;
            }
        }
        return best;
    }

    static boolean hasBuilding(ServerWorld world) {
        for (Wall wall : WALLS) {
            if (wall.world == world && wall.phase == Wall.Phase.BUILDING) return true;
        }
        return false;
    }

    static void startFall(MinecraftServer server, Wall wall, int sx, int si) {
        wall.schedule = wall.buildSchedule(sx, si);
        wall.fallCursor = 0;
        wall.fallStart = server.getTicks();
        wall.phase = Wall.Phase.FALLING;
        fallStep(server, wall); // сразу, чтобы убрать факелы над сломанным до того, как блок упадёт
    }

    private static void tick(MinecraftServer server) {
        if (WALLS.isEmpty()) return;
        Iterator<Wall> it = WALLS.iterator();
        while (it.hasNext()) {
            Wall wall = it.next();
            switch (wall.phase) {
                case BUILDING -> buildStep(server, wall);
                case FALLING -> fallStep(server, wall);
                case DONE -> {
                    if (server.getTicks() > wall.doneTick + 200) it.remove();
                }
                default -> { }
            }
        }
    }

    private static void buildStep(MinecraftServer server, Wall wall) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        int total = wall.totalCells();
        int end = Math.min(total, wall.buildCursor + BUILD_PER_TICK);
        for (int c = wall.buildCursor; c < end; c++) {
            wall.cellPos(c, m);
            wall.world.setBlockState(m, wall.cellState(c), Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
        }
        wall.buildCursor = end;
        if (end >= total) {
            wall.phase = Wall.Phase.READY;
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(wall.owner);
            if (p != null) {
                p.sendMessage(Text.literal("Стена готова. Сломай любой факел (или введи /pixelart fall)."), false);
            }
        }
    }

    private static void fallStep(MinecraftServer server, Wall wall) {
        int elapsed = server.getTicks() - wall.fallStart;
        int budget = REMOVE_PER_TICK;
        int tCount = wall.h - 1;
        BlockPos.Mutable m = new BlockPos.Mutable();
        while (wall.fallCursor < wall.schedule.length && budget > 0) {
            long key = wall.schedule[wall.fallCursor];
            int delay = (int) (key >>> 40);
            if (delay > elapsed) break;
            int ti = tCount - 1 - (int) ((key >>> 20) & 0xFFFFF);
            int cx = (int) (key & 0xFFFFF);
            wall.torchPos(cx, ti, m);
            if (wall.world.getBlockState(m).isOf(Blocks.TORCH)) {
                wall.world.setBlockState(m, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                budget--;
            }
            wall.fallCursor++;
        }
        if (wall.fallCursor >= wall.schedule.length) {
            wall.phase = Wall.Phase.DONE;
            wall.doneTick = server.getTicks();
        }
    }
}
