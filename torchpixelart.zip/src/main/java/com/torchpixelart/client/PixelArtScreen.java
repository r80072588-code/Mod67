package com.torchpixelart.client;

import com.torchpixelart.FallMode;
import com.torchpixelart.ImageFolder;
import com.torchpixelart.ImageProcessor;
import com.torchpixelart.Palette;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

/** Меню мода: выбор картинки, размера, вида падения, предпросмотр. */
public class PixelArtScreen extends Screen {
    private static final int[] WIDTHS = {16, 24, 32, 48, 64, 80, 96, 112, 128};
    private static final int[] HEIGHTS = {0, 8, 16, 24, 32, 48, 64, 80, 96, 112, 128}; // 0 = авто
    private static final FallMode[] MODES = FallMode.values();

    // настройки запоминаются между открытиями
    private static int widthIdx = 4;
    private static int heightIdx = 0;
    private static int modeIdx = 0;
    private static boolean dither = true;
    private static String lastFile = null;

    private static final int X0 = 20;
    private static final int Y0 = 40;
    private static final int STEP = 22;

    private final Screen parent;
    private final List<String> files = new ArrayList<>();
    private int fileIdx = 0;

    private BufferedImage image;
    private String imageName;
    private int[] previewPix;
    private int previewW;
    private int previewH;
    private String status = "";

    private ButtonWidget ditherButton;

    public PixelArtScreen(Screen parent) {
        super(Text.literal("Torch Pixel Art"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        refreshFiles();

        addDrawableChild(small("<", X0, Y0, () -> stepFile(-1)));
        addDrawableChild(small(">", X0 + 170, Y0, () -> stepFile(1)));

        addDrawableChild(small("-", X0, Y0 + STEP, () -> {
            widthIdx = Math.max(0, widthIdx - 1);
            updatePreview();
        }));
        addDrawableChild(small("+", X0 + 170, Y0 + STEP, () -> {
            widthIdx = Math.min(WIDTHS.length - 1, widthIdx + 1);
            updatePreview();
        }));

        addDrawableChild(small("-", X0, Y0 + STEP * 2, () -> {
            heightIdx = Math.max(0, heightIdx - 1);
            updatePreview();
        }));
        addDrawableChild(small("+", X0 + 170, Y0 + STEP * 2, () -> {
            heightIdx = Math.min(HEIGHTS.length - 1, heightIdx + 1);
            updatePreview();
        }));

        addDrawableChild(small("<", X0, Y0 + STEP * 3, () -> {
            modeIdx = Math.floorMod(modeIdx - 1, MODES.length);
        }));
        addDrawableChild(small(">", X0 + 170, Y0 + STEP * 3, () -> {
            modeIdx = Math.floorMod(modeIdx + 1, MODES.length);
        }));

        ditherButton = addDrawableChild(ButtonWidget.builder(ditherText(), b -> {
            dither = !dither;
            b.setMessage(ditherText());
            updatePreview();
        }).dimensions(X0, Y0 + STEP * 4, 190, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Построить"), b -> build())
                .dimensions(X0, Y0 + STEP * 5 + 6, 190, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Обновить список файлов"), b -> {
            refreshFiles();
            updatePreview();
        }).dimensions(X0, Y0 + STEP * 6 + 6, 190, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
                .dimensions(X0, Y0 + STEP * 7 + 6, 190, 20).build());

        updatePreview();
    }

    private static ButtonWidget small(String label, int x, int y, Runnable action) {
        return ButtonWidget.builder(Text.literal(label), b -> action.run())
                .dimensions(x, y, 20, 20).build();
    }

    private static Text ditherText() {
        return Text.literal("Дизеринг (мягкие переходы): " + (dither ? "вкл" : "выкл"));
    }

    private void refreshFiles() {
        files.clear();
        files.addAll(ImageFolder.list());
        fileIdx = 0;
        if (lastFile != null) {
            int i = files.indexOf(lastFile);
            if (i >= 0) fileIdx = i;
        }
        image = null;
        imageName = null;
    }

    private void stepFile(int d) {
        if (files.isEmpty()) return;
        fileIdx = Math.floorMod(fileIdx + d, files.size());
        updatePreview();
    }

    private void updatePreview() {
        previewPix = null;
        status = "";
        if (files.isEmpty()) {
            status = "Положи PNG/JPG в папку .minecraft/pixelart";
            return;
        }
        String name = files.get(fileIdx);
        try {
            if (image == null || !name.equals(imageName)) {
                image = ImageProcessor.load(ImageFolder.dir().resolve(name).toFile());
                imageName = name;
            }
            int w = WIDTHS[widthIdx];
            int h = HEIGHTS[heightIdx] == 0 ? ImageProcessor.autoHeight(image, w) : HEIGHTS[heightIdx];
            previewPix = ImageProcessor.quantize(image, w, h, dither);
            previewW = w;
            previewH = h;
            status = w + " x " + h + " блоков, стройка высотой " + (2 * h - 1);
        } catch (Exception e) {
            image = null;
            status = "Ошибка: " + e.getMessage();
        }
    }

    private void build() {
        if (files.isEmpty() || client == null || client.player == null) return;
        String name = files.get(fileIdx);
        lastFile = name;
        String escaped = name.replace("\\", "\\\\").replace("\"", "\\\"");
        String cmd = "pixelart build \"" + escaped + "\" " + WIDTHS[widthIdx] + " " + HEIGHTS[heightIdx]
                + " " + MODES[modeIdx].id + " " + dither;
        client.setScreen(null);
        client.player.networkHandler.sendChatCommand(cmd);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFFFF);

        int tx = X0 + 95;
        String fileText = files.isEmpty() ? "(нет файлов)" : textRenderer.trimToWidth(files.get(fileIdx), 140);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(fileText), tx, Y0 + 6, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Ширина: " + WIDTHS[widthIdx]),
                tx, Y0 + STEP + 6, 0xFFFFFFFF);
        String hText = HEIGHTS[heightIdx] == 0 ? "авто" : String.valueOf(HEIGHTS[heightIdx]);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Высота: " + hText),
                tx, Y0 + STEP * 2 + 6, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(MODES[modeIdx].label),
                tx, Y0 + STEP * 3 + 6, 0xFFFFC040);

        int ax = X0 + 210;
        int ay = Y0;
        int aw = Math.max(40, width - ax - 20);
        int ah = Math.max(40, height - ay - 50);
        ctx.fill(ax - 1, ay - 1, ax + aw + 1, ay + ah + 1, 0xFF303030);
        ctx.fill(ax, ay, ax + aw, ay + ah, 0xFF101010);

        if (previewPix != null) {
            int st = 1;
            while ((previewW + st - 1) / st > aw || (previewH + st - 1) / st > ah) st++;
            int gw = (previewW + st - 1) / st;
            int gh = (previewH + st - 1) / st;
            int cs = Math.max(1, Math.min(aw / gw, ah / gh));
            int px0 = ax + (aw - gw * cs) / 2;
            int py0 = ay + (ah - gh * cs) / 2;
            for (int gy = 0; gy < gh; gy++) {
                for (int gx = 0; gx < gw; gx++) {
                    int c = Palette.RGB[previewPix[gy * st * previewW + gx * st]];
                    int x = px0 + gx * cs;
                    int y = py0 + gy * cs;
                    ctx.fill(x, y, x + cs, y + cs, 0xFF000000 | c);
                }
            }
        }

        ctx.drawTextWithShadow(textRenderer, Text.literal(status), ax, ay + ah + 6, 0xFFA0A0A0);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Папка: .minecraft/pixelart"),
                ax, ay + ah + 18, 0xFF808080);
    }
}
