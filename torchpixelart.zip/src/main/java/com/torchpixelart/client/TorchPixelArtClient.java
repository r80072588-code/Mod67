package com.torchpixelart.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class TorchPixelArtClient implements ClientModInitializer {
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.torchpixelart.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                "category.torchpixelart"));

        // Клавиша K открывает меню прямо в игре
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.player != null && client.currentScreen == null) {
                    client.setScreen(new PixelArtScreen(null));
                }
            }
        });

        // Кнопка "Pixel Art" в меню паузы (Esc)
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen) {
                ButtonWidget button = ButtonWidget.builder(Text.literal("Pixel Art"),
                                b -> client.setScreen(new PixelArtScreen(screen)))
                        .dimensions(6, 6, 80, 20)
                        .build();
                Screens.getButtons(screen).add(button);
            }
        });
    }
}
